from datetime import date
from dateutil.parser import parse

import calendar
import datetime


def addYears(d, years):
    try:
#Return same day of the current year        
        return d.replace(year = d.year + years)
    except ValueError:
#If not same day, it will return other, i.e.  February 29 to March 1 etc.        
        return d + (date(d.year + years, 1, 1) - date(d.year, 1, 1))


def findMonthRange(searchExpiryDate):
     dt = parse(searchExpiryDate)
     year = dt.year
     month = dt.month
     day = calendar.monthrange(year,month)[1]
     updatedSearchDate = addYears(datetime.date(year,month,day),3)
     print(calendar.monthrange(year,month)[1])
     print("updatedSearchDate:",updatedSearchDate)
     return updatedSearchDate


