
import csv
import os

def searchCSV(searchUserId):
        csvFile = os.path.abspath(
            '..') + "\\main\\JavaCodingQuestions\\InputData\\SourceCSV.csv"
        print("csvFile Location: "+csvFile)

        # read csv, and split on "," the line
        csv_file = csv.reader(open(csvFile, "r"), delimiter=",")

        # loop through the csv list
        for row in csv_file:
        # if current rows 2nd value is equal to input, print that row
            if searchUserId == row[0]:
                searchExpiryDate = row[2]
        print('searchExpiryDate:: '+searchExpiryDate)
        return searchExpiryDate