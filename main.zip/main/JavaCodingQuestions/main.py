'''
Created on July 24, 2021
@author: Asiyath A
'''
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from dateCalulator import *
from searchCSV import *

import time
import os



class main():

    def test(self):
        baseUrl = os.path.abspath(
            '..') + "\\main\\JavaCodingQuestions\\InputData\\HTML_sample.html"
        print("baseUrl: "+baseUrl)

        driver = webdriver.Chrome(ChromeDriverManager().install())
        driver.maximize_window()
        driver.get(baseUrl)
        driver.execute_script("window.scrollBy(0, 1000);")

        # Switch to frame1 using name
        driver.switch_to.frame("frm1")
        # Switch to frame2 using name
        driver.switch_to.frame("frm2")

        time.sleep(2)
        usrid = driver.find_elements_by_xpath('//*[@id="usrid"]')
        print("Count of user id present: ", len(usrid))
       
        #Find the used id from the html page
        for value in usrid:
            searchUserId = value.text

        #Finding the expiring date by iterating through the CSV rows
        searchExpiryDate = searchCSV(searchUserId)
        
        #Updating expiry date to last day of the month 
        updatedSearchDate = findMonthRange(searchExpiryDate)
       
        # Search course
        searchExpiryDate = driver.find_element(By.ID, "expiryData")
        searchExpiryDate.clear()
        searchExpiryDate.send_keys(str(updatedSearchDate))
        time.sleep(2)

        # Switch back to the parent frame
        driver.switch_to.default_content()
        driver.execute_script("window.scrollBy(0, -1000);")
        time.sleep(5)

        driver.close()
        driver.quit()


ff = main()
ff.test()

